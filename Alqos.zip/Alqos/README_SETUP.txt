Alqos - Setup & Build Guide (Minimal)
-------------------------------------
Ini adalah paket starter untuk:
- alqos_reader (Flutter) - Dark mode, no-auth (demo)
- alqos_admin (React)  - Dark dashboard, no-auth (demo)

1) Flutter Reader
   - Masuk ke folder: alqos_reader
   - Install Flutter SDK: https://flutter.dev/docs/get-started/install
   - Jalankan: flutter pub get
   - Untuk web: flutter run -d chrome
   - Untuk Android: flutter run -d <device>

   Catatan: file firebase_options.dart disertakan kosong; kalau mau konek Firebase, isi sesuai instruksi di README di dalam folder.

2) React Admin
   - Masuk ke folder: alqos_admin
   - Pastikan Node.js & npm atau yarn terpasang
   - Jalankan: npm install
   - Jalankan dev server: npm start
   - firebase_config.js disediakan kosong; isi jika ingin koneksi Firebase.

Struktur:
  Alqos/
    alqos_reader/     -> Flutter starter (dark theme)
    alqos_admin/      -> React starter (dark dashboard)
    README_SETUP.txt  -> file ini

Lisensi: Ini starter demo. Lengkapi, amankan rules, dan tambahkan autentikasi sebelum produksi.
