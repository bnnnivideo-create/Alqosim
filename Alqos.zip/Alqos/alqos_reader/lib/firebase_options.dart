// firebase_options.dart
// Kosong - silakan isi konfigurasi Firebase jika ingin memakai Firebase.
// Contoh struktur (ganti nilainya dengan config project kamu):
//
// const firebaseOptions = {
//   "apiKey": "...",
//   "authDomain": "...",
//   "projectId": "...",
//   "storageBucket": "...",
//   "messagingSenderId": "...",
//   "appId": "..."
// };
//
const firebaseOptions = {};
