import 'package:flutter/material.dart';
import 'screens/home.dart';

void main() {
  runApp(AlqosApp());
}

class AlqosApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Alqos',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Color(0xFF121212),
        primaryColor: Color(0xFF7C4DFF),
        colorScheme: ColorScheme.dark(
          primary: Color(0xFF7C4DFF),
          secondary: Color(0xFF4FC3F7),
        ),
        textTheme: TextTheme(
          bodyText1: TextStyle(color: Colors.white70),
          bodyText2: TextStyle(color: Colors.white60),
        ),
      ),
      home: HomeScreen(),
    );
  }
}
