import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Demo list of books (static). Replace with Firestore integration later.
    final books = [
      {'title': 'Contoh Buku Satu', 'author': 'Penulis A'},
      {'title': 'Contoh Buku Dua', 'author': 'Penulis B'},
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text('Perpustakaan Alqos'),
        elevation: 0,
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(12),
        itemCount: books.length,
        itemBuilder: (context, i) {
          final b = books[i];
          return Card(
            color: Color(0xFF1E1E1E),
            margin: EdgeInsets.symmetric(vertical: 8),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: ListTile(
              title: Text(b['title']!, style: TextStyle(color: Colors.white)),
              subtitle: Text(b['author']!, style: TextStyle(color: Colors.white60)),
              trailing: Icon(Icons.chevron_right, color: Colors.white54),
              onTap: () {
                // placeholder: open detail / reader
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Buka: ' + b['title']!)));
              },
            ),
          );
        },
      ),
    );
  }
}
