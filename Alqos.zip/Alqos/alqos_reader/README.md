Alqos - Flutter Reader (dark demo)
---------------------------------
Folder ini berisi starter Flutter untuk reader dalam mode gelap.
- Demo ini **tanpa autentikasi** dan memuat daftar buku statis.
- Untuk koneksi Firebase: isi file `lib/firebase_options.dart` dengan config project kamu,
  lalu tambahkan paket firebase_core & firebase_auth & cloud_firestore sesuai kebutuhan.
