// firebase_config.js
// Kosong - isi bila ingin menghubungkan ke Firebase
// Contoh:
// export const firebaseConfig = {
//   apiKey: '...',
//   authDomain: '...',
//   projectId: '...',
//   storageBucket: '...',
//   messagingSenderId: '...',
//   appId: '...'
// };
export const firebaseConfig = {};
