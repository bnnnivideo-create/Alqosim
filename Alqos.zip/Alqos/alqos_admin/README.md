Alqos - Admin Dashboard (demo)
------------------------------
- Buat folder ini sebagai React app (Create React App template).
- Demo ini **tanpa autentikasi** — hanya tampilan UI.
- Untuk menambahkan Firebase, isi file `firebase_config.js` dengan config project kamu.
