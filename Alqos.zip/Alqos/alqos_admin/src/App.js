import React from 'react';
import Books from './pages/Books';

export default function App(){
  return (
    <div className='app'>
      <aside className='sidebar'>
        <h2>Alqos Admin</h2>
        <nav>
          <a href='#'>Books</a>
        </nav>
      </aside>
      <main className='main'>
        <Books />
      </main>
    </div>
  );
}
