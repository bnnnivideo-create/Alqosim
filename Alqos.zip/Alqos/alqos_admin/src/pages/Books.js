import React from 'react';

export default function Books(){
  const books = [
    {id:1, title:'Contoh Buku Satu', author:'Penulis A'},
    {id:2, title:'Contoh Buku Dua', author:'Penulis B'},
  ];
  return (
    <div className='page'>
      <h1>Daftar Buku</h1>
      <div className='grid'>
        {books.map(b => (
          <div key={b.id} className='card'>
            <h3>{b.title}</h3>
            <p>{b.author}</p>
            <button>Edit</button>
          </div>
        ))}
      </div>
    </div>
  );
}
